const Board = require('./board.model');

let boards = [new Board()]

const getAll = async () => boards
const getById = async id => boards.find(item => item.id === id)
const postBoard = async board => {
  const newBoard = new Board({...board})

  boards.push(newBoard)
  console.log(newBoard)

  return newBoard
}
const putBoard = async (id, board) => {
  const findedBoard = boards.find(item => item.id === id)

  findedBoard.title = board.title;
  findedBoard.order = board.order;
  findedBoard.description = board.description;
  findedBoard.userId = board.userId;
  findedBoard.boardId = board.boardId;
  findedBoard.columnId = board.columnId;

  return boards;
}
const deleteBoard = async id => {
  const findedBoard = getById(id);

  boards = boards.filter(item => item.id !== id)

  return findedBoard
}

module.exports = { getAll, getById, postBoard, putBoard, deleteBoard }
