const router = require('express').Router();
const Board = require('./board.model');
const boardService = require('./board.service');

router.route('/').get(async (req, res) => {
  const boards = await boardService.getAll();

  res.statusCode = 200;
  res.json(boards);
});

router.route('/:id').get(async (req, res) => {
  const board = await boardService.getById(req.params.id);

  res.statusCode = 200;
  res.json(board);
});

router.route('/').post(async (req, res) => {
  const board = await boardService.postBoard(req.body);

  res.statusCode = 201;
  res.json(board);
});

router.route('/:id').put(async (req, res) => {
  const boards = await boardService.putBoard(req.params.id, req.body);

  res.statusCode = 200;
  res.json(boards);
});

router.route('/:id').delete(async (req, res) => {
  const findedBoard = await boardService.deleteBoard(req.params.id);

  res.statusCode = 204;
  res.json(findedUser);
});

module.exports = router;
