const Board_module = require('./board.memory.repository');

const getAll = () => Board_module.getAll();
const getById = id => Board_module.getById(id);
const postBoard = board => Board_module.postBoard(board);
const putBoard = (id, board) => Board_module.putBoard(id, board);
const deleteBoard = id => Board_module.deleteBoard(id);

module.exports = { getAll, getById, postBoard, putBoard, deleteBoard };
