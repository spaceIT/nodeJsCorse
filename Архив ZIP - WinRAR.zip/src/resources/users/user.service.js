const User_module = require('./user.memory.repository');

const getAll = () => User_module.getAll();
const getById = id => User_module.getById(id);
const postUser = user => User_module.postUser(user);
const putUser = (id, user) => User_module.putUser(id, user);
const deleteUser = id => User_module.deleteUser(id);

module.exports = { getAll, getById, postUser, putUser, deleteUser };
