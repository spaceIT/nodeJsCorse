const User = require('./user.model');

let users = [new User()]

const getAll = async () => users
const getById = async id => users.find(item => item.id === id)
const postUser = async user => {
  const newUser = new User(user)

  users.push(newUser)

  return newUser
}
const putUser = async (id, user) => {
  const findedUser = users.find(item => item.id === id)

  findedUser.name = user.name
  findedUser.login = user.login
  findedUser.password = user.password

  return users
}
const deleteUser = async id => {
  const findedUser = getById(id);
  
  users = users.filter(item => item.id !== id)

  return findedUser
}

module.exports = { getAll, getById, postUser, putUser, deleteUser }
