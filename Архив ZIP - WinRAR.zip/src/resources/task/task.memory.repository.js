const Task = require('./task.model');

let tasks = [new Task()]

const getAll = async () => tasks
const getById = async id => tasks.find(item => item.id === id)
const postTask = async task => {
  const newTask = new Task(task)

  tasks.push(newTask)

  return newTask
}
const putTask = async (id, task) => {
  const findedTask = tasks.find(item => item.id === id)

  findedTask.title = task.title;
  findedTask.order = task.order;
  findedTask.description = task.description;
  findedTask.userId = task.userId;
  findedTask.boardId = task.boardId;
  findedTask.columnId = task.columnId;

  return tasks;
}
const deleteTask = async id => {
  const findedTask = getById(id);

  tasks = tasks.filter(item => item.id !== id)

  return findedTask
}

module.exports = { getAll, getById, postTask, putTask, deleteTask }
