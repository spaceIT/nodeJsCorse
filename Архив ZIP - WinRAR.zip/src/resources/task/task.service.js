const Task_module = require('./task.memory.repository');

const getAll = () => Task_module.getAll();
const getById = id => Task_module.getById(id);
const postTask = task => Task_module.postTask(task);
const putTask = (id, task) => Task_module.putTask(id, task);
const deleteTask = id => Task_module.deleteTask(id);

module.exports = { getAll, getById, postTask, putTask, deleteTask };
