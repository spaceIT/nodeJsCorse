const createAuthorizedRequest = require('./createAuthorizedRequest');
const shouldAuthorizationBeTested = require('./shouldAuthorizationBeTested');
module.exports = {
  createAuthorizedRequest,
  shouldAuthorizationBeTested
};
